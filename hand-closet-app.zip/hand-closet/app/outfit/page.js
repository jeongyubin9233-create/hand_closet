"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import AppShell from "@/components/AppShell";
import { useAuth } from "@/lib/useAuth";
import { showToast } from "@/lib/toast";

const BOARD_W = 320;
const BOARD_H = 400;

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

export default function OutfitPage() {
  const { user, loading, logout } = useAuth();
  const router = useRouter();
  const [items, setItems] = useState([]);
  const [board, setBoard] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [lookName, setLookName] = useState("");
  const [saving, setSaving] = useState(false);
  const boardRef = useRef(null);
  const dragState = useRef(null);

  useEffect(() => {
    if (loading) return;
    if (!user) {
      router.replace("/login");
      return;
    }
    (async () => {
      const res = await fetch("/api/items");
      const data = await res.json();
      setItems(Array.isArray(data) ? data : []);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, user]);

  async function addToBoard(item) {
    const img = await loadImage(item.imageBase64);
    const count = board.length;
    const offset = (count % 5) * 14;
    setBoard((prev) => [
      ...prev,
      {
        boardId: uid(),
        itemId: item.id,
        imageBase64: item.imageBase64,
        x: BOARD_W / 2 - 30 + offset,
        y: BOARD_H / 2 - 30 + offset,
        w: 110,
        ratio: img.height / img.width,
      },
    ]);
  }

  function removeFromBoard(boardId) {
    setBoard((prev) => prev.filter((b) => b.boardId !== boardId));
    if (selectedId === boardId) setSelectedId(null);
  }

  function handlePointerDown(e, boardId) {
    e.preventDefault();
    e.stopPropagation();
    setSelectedId(boardId);
    const rect = boardRef.current.getBoundingClientRect();
    dragState.current = { boardId, rect };
    window.addEventListener("pointermove", handlePointerMove);
    window.addEventListener("pointerup", handlePointerUp);
  }

  function handlePointerMove(e) {
    const ds = dragState.current;
    if (!ds) return;
    const relX = ((e.clientX - ds.rect.left) / ds.rect.width) * BOARD_W;
    const relY = ((e.clientY - ds.rect.top) / ds.rect.height) * BOARD_H;
    const x = Math.max(0, Math.min(BOARD_W, relX));
    const y = Math.max(0, Math.min(BOARD_H, relY));
    setBoard((prev) => prev.map((b) => (b.boardId === ds.boardId ? { ...b, x, y } : b)));
  }

  function handlePointerUp() {
    dragState.current = null;
    window.removeEventListener("pointermove", handlePointerMove);
    window.removeEventListener("pointerup", handlePointerUp);
  }

  useEffect(() => {
    return () => {
      window.removeEventListener("pointermove", handlePointerMove);
      window.removeEventListener("pointerup", handlePointerUp);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function openSaveModal() {
    setLookName(`코디 ${new Date().toLocaleDateString("ko-KR")}`);
    setShowSaveModal(true);
  }

  async function confirmSave() {
    setSaving(true);
    try {
      const scale = 2;
      const canvas = document.createElement("canvas");
      canvas.width = BOARD_W * scale;
      canvas.height = BOARD_H * scale;
      const ctx = canvas.getContext("2d");

      for (const b of board) {
        const img = await loadImage(b.imageBase64);
        const wpx = b.w * scale;
        const hpx = wpx * (img.height / img.width);
        const xpx = b.x * scale - wpx / 2;
        const ypx = b.y * scale - hpx / 2;
        ctx.drawImage(img, xpx, ypx, wpx, hpx);
      }
      const thumbBase64 = canvas.toDataURL("image/png");

      const res = await fetch("/api/looks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: lookName.trim() || "이름 없는 코디",
          thumbBase64,
          items: board.map(({ itemId, x, y, w, ratio }) => ({ itemId, x, y, w, ratio })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "저장에 실패했어요.");

      setShowSaveModal(false);
      setBoard([]);
      setSelectedId(null);
      showToast("코디가 저장되었어요");
      router.push("/lookbook");
    } catch (err) {
      showToast(err.message || "저장 중 오류가 발생했어요.");
    } finally {
      setSaving(false);
    }
  }

  if (loading || !user) {
    return <div className="center-loading">불러오는 중…</div>;
  }

  return (
    <AppShell user={user} onLogout={logout}>
      <h1 className="page-title">코디하기</h1>
      <p className="sub">아이템을 눌러 보드에 올리고, 드래그로 배치해보세요.</p>

      <div
        className="board-wrap"
        ref={boardRef}
        onClick={(e) => e.target === boardRef.current && setSelectedId(null)}
      >
        {board.length === 0 && (
          <div className="board-hint">
            아래에서 아이템을 눌러
            <br />
            보드에 올려보세요
          </div>
        )}
        {board.map((b) => (
          <div
            key={b.boardId}
            className={`board-item${selectedId === b.boardId ? " selected" : ""}`}
            style={{
              left: `${(b.x / BOARD_W) * 100}%`,
              top: `${(b.y / BOARD_H) * 100}%`,
              width: `${(b.w / BOARD_W) * 100}%`,
            }}
            onPointerDown={(e) => handlePointerDown(e, b.boardId)}
            onClick={(e) => {
              e.stopPropagation();
              setSelectedId(b.boardId);
            }}
          >
            <img src={b.imageBase64} draggable={false} alt="" />
            <button
              className="item-del"
              onClick={(e) => {
                e.stopPropagation();
                removeFromBoard(b.boardId);
              }}
            >
              ✕
            </button>
          </div>
        ))}
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div className="palette-label">내 옷장에서 선택</div>
        {board.length > 0 && (
          <button className="btn small" onClick={openSaveModal}>
            저장하기
          </button>
        )}
      </div>

      {items.length > 0 ? (
        <div className="palette">
          {items.map((item) => (
            <div className="palette-item" key={item.id} onClick={() => addToBoard(item)}>
              <img src={item.imageBase64} alt={item.name} />
            </div>
          ))}
        </div>
      ) : (
        <div className="empty">옷장에 아이템을 먼저 추가해주세요</div>
      )}

      {showSaveModal && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setShowSaveModal(false)}>
          <div className="modal">
            <h3>코디 저장하기</h3>
            <div className="field">
              <label>코디 이름</label>
              <input type="text" value={lookName} onChange={(e) => setLookName(e.target.value)} />
            </div>
            <div className="modal-actions">
              <button className="btn outline" onClick={() => setShowSaveModal(false)} disabled={saving}>
                취소
              </button>
              <button className="btn" onClick={confirmSave} disabled={saving}>
                {saving ? "저장 중…" : "저장"}
              </button>
            </div>
          </div>
        </div>
      )}
    </AppShell>
  );
}
