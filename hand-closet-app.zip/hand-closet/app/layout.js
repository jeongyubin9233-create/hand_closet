import "./globals.css";

export const metadata = {
  title: "HAND CLOSET",
  description: "나만의 옷장을 만들어보세요.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="ko">
      <body>{children}</body>
    </html>
  );
}
