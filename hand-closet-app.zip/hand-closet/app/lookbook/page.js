"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import AppShell from "@/components/AppShell";
import { useAuth } from "@/lib/useAuth";
import { showToast } from "@/lib/toast";

export default function LookbookPage() {
  const { user, loading, logout } = useAuth();
  const router = useRouter();
  const [looks, setLooks] = useState([]);
  const [looksLoading, setLooksLoading] = useState(true);
  const [viewing, setViewing] = useState(null);

  useEffect(() => {
    if (loading) return;
    if (!user) {
      router.replace("/login");
      return;
    }
    loadLooks();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, user]);

  async function loadLooks() {
    setLooksLoading(true);
    try {
      const res = await fetch("/api/looks");
      const data = await res.json();
      setLooks(Array.isArray(data) ? data : []);
    } finally {
      setLooksLoading(false);
    }
  }

  async function handleDelete(id) {
    await fetch(`/api/looks/${id}`, { method: "DELETE" });
    setLooks((prev) => prev.filter((l) => l.id !== id));
    setViewing(null);
    showToast("코디를 삭제했어요");
  }

  if (loading || !user) {
    return <div className="center-loading">불러오는 중…</div>;
  }

  return (
    <AppShell user={user} onLogout={logout}>
      <h1 className="page-title">저장한 코디</h1>
      <p className="sub">저장한 코디를 모아볼 수 있어요.</p>

      {looksLoading ? (
        <div className="empty">불러오는 중…</div>
      ) : looks.length > 0 ? (
        <div className="look-grid">
          {looks.map((l) => (
            <div className="look-card" key={l.id} onClick={() => setViewing(l)}>
              <div className="thumb">
                <img src={l.thumbBase64} alt={l.name} />
              </div>
              <div className="meta">
                <div className="name">{l.name}</div>
                <div className="date">{new Date(l.createdAt).toLocaleDateString("ko-KR")}</div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="empty">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#8A8471" strokeWidth="1.5">
            <path d="M19 21l-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
          </svg>
          <div>저장된 코디가 없어요</div>
        </div>
      )}

      {viewing && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setViewing(null)}>
          <div className="modal">
            <h3>{viewing.name}</h3>
            <div className="preview-box" style={{ height: 340 }}>
              <img src={viewing.thumbBase64} alt={viewing.name} />
            </div>
            <p className="sub" style={{ marginBottom: 16 }}>
              {new Date(viewing.createdAt).toLocaleDateString("ko-KR")} 저장
            </p>
            <div className="modal-actions">
              <button className="btn outline" onClick={() => setViewing(null)}>
                닫기
              </button>
              <button className="btn danger" onClick={() => handleDelete(viewing.id)}>
                삭제하기
              </button>
            </div>
          </div>
        </div>
      )}
    </AppShell>
  );
}
