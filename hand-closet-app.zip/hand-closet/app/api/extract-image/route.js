import { NextResponse } from "next/server";
import * as cheerio from "cheerio";
import { getCurrentUserId } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(req) {
  const userId = await getCurrentUserId();
  if (!userId) {
    return NextResponse.json({ error: "로그인이 필요해요." }, { status: 401 });
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "잘못된 요청이에요." }, { status: 400 });
  }

  const url = (body.url || "").trim();
  let target;
  try {
    target = new URL(url);
  } catch {
    return NextResponse.json({ error: "올바른 링크가 아니에요." }, { status: 400 });
  }
  if (!["http:", "https:"].includes(target.protocol)) {
    return NextResponse.json({ error: "http/https 링크만 지원해요." }, { status: 400 });
  }

  try {
    const pageRes = await fetch(target.toString(), {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (compatible; HandClosetBot/1.0; +https://example.com/bot)",
        Accept: "text/html",
      },
      redirect: "follow",
    });

    if (!pageRes.ok) {
      return NextResponse.json(
        { error: "페이지를 불러오지 못했어요. 링크를 다시 확인해주세요." },
        { status: 502 }
      );
    }

    const html = await pageRes.text();
    const $ = cheerio.load(html);

    let image =
      $('meta[property="og:image:secure_url"]').attr("content") ||
      $('meta[property="og:image"]').attr("content") ||
      $('meta[name="twitter:image"]').attr("content") ||
      $('meta[name="twitter:image:src"]').attr("content");

    const rawTitle =
      $('meta[property="og:title"]').attr("content") || $("title").first().text() || "";

    if (!image) {
      return NextResponse.json(
        {
          error:
            "이 페이지에서 상품 이미지를 자동으로 찾지 못했어요. 이미지를 직접 업로드해주세요.",
        },
        { status: 404 }
      );
    }

    // 상대경로일 수 있으니 절대 URL로 변환
    const absoluteImage = new URL(image, target).toString();

    return NextResponse.json({
      imageUrl: absoluteImage,
      title: rawTitle.trim().slice(0, 120),
    });
  } catch (err) {
    console.error("extract-image error:", err);
    return NextResponse.json(
      { error: "링크에서 이미지를 가져오는 중 오류가 발생했어요." },
      { status: 500 }
    );
  }
}
