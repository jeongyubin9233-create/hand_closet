import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUserId } from "@/lib/auth";

export const runtime = "nodejs";

export async function GET() {
  const userId = await getCurrentUserId();
  if (!userId) {
    return NextResponse.json({ error: "로그인이 필요해요." }, { status: 401 });
  }
  const items = await prisma.closetItem.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json(items);
}

export async function POST(req) {
  const userId = await getCurrentUserId();
  if (!userId) {
    return NextResponse.json({ error: "로그인이 필요해요." }, { status: 401 });
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "잘못된 요청이에요." }, { status: 400 });
  }

  const { name, category, imageBase64 } = body;
  if (!name || !category || !imageBase64) {
    return NextResponse.json({ error: "필수 정보가 빠졌어요." }, { status: 400 });
  }

  const item = await prisma.closetItem.create({
    data: { userId, name: String(name).slice(0, 80), category, imageBase64 },
  });
  return NextResponse.json(item);
}
