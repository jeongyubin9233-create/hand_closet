import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUserId } from "@/lib/auth";

export const runtime = "nodejs";

export async function DELETE(req, { params }) {
  const userId = await getCurrentUserId();
  if (!userId) {
    return NextResponse.json({ error: "로그인이 필요해요." }, { status: 401 });
  }
  const { id } = await params;

  const look = await prisma.look.findUnique({ where: { id } });
  if (!look || look.userId !== userId) {
    return NextResponse.json({ error: "코디를 찾을 수 없어요." }, { status: 404 });
  }

  await prisma.look.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
