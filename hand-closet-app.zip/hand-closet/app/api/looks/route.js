import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUserId } from "@/lib/auth";

export const runtime = "nodejs";

export async function GET() {
  const userId = await getCurrentUserId();
  if (!userId) {
    return NextResponse.json({ error: "로그인이 필요해요." }, { status: 401 });
  }
  const looks = await prisma.look.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json(looks);
}

export async function POST(req) {
  const userId = await getCurrentUserId();
  if (!userId) {
    return NextResponse.json({ error: "로그인이 필요해요." }, { status: 401 });
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "잘못된 요청이에요." }, { status: 400 });
  }

  const { name, thumbBase64, items } = body;
  if (!name || !thumbBase64 || !Array.isArray(items)) {
    return NextResponse.json({ error: "필수 정보가 빠졌어요." }, { status: 400 });
  }

  const look = await prisma.look.create({
    data: {
      userId,
      name: String(name).slice(0, 80),
      thumbBase64,
      itemsJson: JSON.stringify(items),
    },
  });
  return NextResponse.json(look);
}
