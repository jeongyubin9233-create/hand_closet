import { NextResponse } from "next/server";
import { getCurrentUserId } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(req) {
  const userId = await getCurrentUserId();
  if (!userId) {
    return NextResponse.json({ error: "로그인이 필요해요." }, { status: 401 });
  }

  const apiKey = process.env.REMOVE_BG_API_KEY;
  if (!apiKey || apiKey === "your-remove-bg-api-key") {
    return NextResponse.json(
      {
        error:
          "REMOVE_BG_API_KEY가 설정되어 있지 않아요. .env 파일에 remove.bg API 키를 넣어주세요.",
      },
      { status: 500 }
    );
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "잘못된 요청이에요." }, { status: 400 });
  }

  const { imageUrl, imageBase64 } = body;

  try {
    const form = new FormData();
    form.append("size", "auto");

    if (imageBase64) {
      const commaIdx = imageBase64.indexOf(",");
      const base64Data = commaIdx >= 0 ? imageBase64.slice(commaIdx + 1) : imageBase64;
      const buffer = Buffer.from(base64Data, "base64");
      form.append("image_file", new Blob([buffer]), "upload.png");
    } else if (imageUrl) {
      form.append("image_url", imageUrl);
    } else {
      return NextResponse.json({ error: "이미지가 없어요." }, { status: 400 });
    }

    const rbRes = await fetch("https://api.remove.bg/v1.0/removebg", {
      method: "POST",
      headers: { "X-Api-Key": apiKey },
      body: form,
    });

    if (!rbRes.ok) {
      let detail = "";
      try {
        detail = await rbRes.text();
      } catch {}
      console.error("remove.bg error:", rbRes.status, detail);

      if (rbRes.status === 402) {
        return NextResponse.json(
          { error: "remove.bg 사용 한도를 초과했어요. 크레딧을 확인해주세요." },
          { status: 402 }
        );
      }
      return NextResponse.json(
        { error: "배경 제거에 실패했어요. 잠시 후 다시 시도해주세요." },
        { status: 502 }
      );
    }

    const arrayBuffer = await rbRes.arrayBuffer();
    const base64 = Buffer.from(arrayBuffer).toString("base64");
    return NextResponse.json({ imageBase64: `data:image/png;base64,${base64}` });
  } catch (err) {
    console.error("remove-bg route error:", err);
    return NextResponse.json({ error: "배경 제거 중 오류가 발생했어요." }, { status: 500 });
  }
}
