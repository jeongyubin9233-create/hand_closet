"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import AppShell from "@/components/AppShell";
import AddItemFlow from "@/components/AddItemFlow";
import { useAuth } from "@/lib/useAuth";

function CardGrid({ items, onDelete }) {
  return (
    <div className="grid">
      {items.map((item) => (
        <div className="card" key={item.id}>
          <img src={item.imageBase64} alt={item.name} />
          <button className="del" onClick={() => onDelete(item.id)}>
            ✕
          </button>
        </div>
      ))}
    </div>
  );
}

export default function HomePage() {
  const { user, loading, logout } = useAuth();
  const router = useRouter();
  const [items, setItems] = useState([]);
  const [itemsLoading, setItemsLoading] = useState(true);
  const [linkUrl, setLinkUrl] = useState("");
  const [flowSource, setFlowSource] = useState(null);
  const fileInputRef = useRef(null);

  useEffect(() => {
    if (user) loadItems();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  async function loadItems() {
    setItemsLoading(true);
    try {
      const res = await fetch("/api/items");
      const data = await res.json();
      setItems(Array.isArray(data) ? data : []);
    } finally {
      setItemsLoading(false);
    }
  }

  async function handleDelete(id) {
    await fetch(`/api/items/${id}`, { method: "DELETE" });
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  function handleLinkSubmit(e) {
    e.preventDefault();
    const url = linkUrl.trim();
    if (!url) return;
    setFlowSource({ type: "link", url });
  }

  function handleFileChange(e) {
    const file = e.target.files[0];
    e.target.value = "";
    if (!file) return;
    setFlowSource({ type: "upload", file });
  }

  if (loading || user === undefined) {
    return <div className="center-loading">불러오는 중…</div>;
  }

  if (!user) {
    return (
      <div className="auth-wrap">
        <div className="logo">HAND CLOSET</div>
        <h1 className="page-title" style={{ marginTop: 14 }}>
          나만의 옷장을
          <br />
          만들어보세요.
        </h1>
        <p className="sub">
          상품 링크나 이미지를 올리면 AI가 배경을 지워서
          <br />내 옷장에 정리해드려요.
        </p>
        <Link href="/signup" className="btn block" style={{ marginBottom: 10 }}>
          회원가입하고 시작하기
        </Link>
        <Link href="/login" className="btn outline block">
          로그인
        </Link>
      </div>
    );
  }

  return (
    <AppShell user={user} onLogout={logout}>
      <h1 className="page-title">
        나만의 옷장을
        <br />
        만들어보세요.
      </h1>
      <p className="sub">
        상품 링크를 붙여넣거나 이미지를 올리면
        <br />
        배경을 자동으로 지워서 옷장에 저장해드려요.
      </p>

      <form className="link-form" onSubmit={handleLinkSubmit}>
        <input
          type="text"
          placeholder="상품 링크를 붙여넣어주세요"
          value={linkUrl}
          onChange={(e) => setLinkUrl(e.target.value)}
        />
        <button className="btn" type="submit">
          가져오기
        </button>
      </form>

      <div className="or-divider">또는</div>

      <div className="upload-zone">
        <p>이미지를 직접 업로드할 수도 있어요</p>
        <button className="btn" onClick={() => fileInputRef.current?.click()}>
          이미지로 아이템 추가하기
        </button>
      </div>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        style={{ display: "none" }}
        onChange={handleFileChange}
      />

      <div className="stat-row" onClick={() => router.push("/closet")}>
        <div>
          <div className="num">{items.length}</div>
          <div className="label">내 옷장 아이템</div>
        </div>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
          <path d="M9 18l6-6-6-6" />
        </svg>
      </div>

      {!itemsLoading && items.length > 0 && (
        <>
          <div className="section-label">최근 추가한 아이템</div>
          <CardGrid items={items.slice(0, 6)} onDelete={handleDelete} />
        </>
      )}

      {flowSource && (
        <AddItemFlow
          source={flowSource}
          onClose={() => setFlowSource(null)}
          onAdded={() => loadItems()}
        />
      )}
    </AppShell>
  );
}
