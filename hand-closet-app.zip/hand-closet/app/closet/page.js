"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import AppShell from "@/components/AppShell";
import { useAuth } from "@/lib/useAuth";

const CATEGORIES = ["상의", "하의", "아우터", "원피스", "신발", "가방", "액세서리"];

export default function ClosetPage() {
  const { user, loading, logout } = useAuth();
  const router = useRouter();
  const [items, setItems] = useState([]);
  const [itemsLoading, setItemsLoading] = useState(true);
  const [filter, setFilter] = useState("전체");

  useEffect(() => {
    if (loading) return;
    if (!user) {
      router.replace("/login");
      return;
    }
    loadItems();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, user]);

  async function loadItems() {
    setItemsLoading(true);
    try {
      const res = await fetch("/api/items");
      const data = await res.json();
      setItems(Array.isArray(data) ? data : []);
    } finally {
      setItemsLoading(false);
    }
  }

  async function handleDelete(id) {
    await fetch(`/api/items/${id}`, { method: "DELETE" });
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  if (loading || !user) {
    return <div className="center-loading">불러오는 중…</div>;
  }

  const presentCats = ["전체", ...CATEGORIES.filter((c) => items.some((i) => i.category === c))];
  const filtered = filter === "전체" ? items : items.filter((i) => i.category === filter);

  return (
    <AppShell user={user} onLogout={logout}>
      <h1 className="page-title">내 옷장</h1>
      <p className="sub">{items.length}개의 아이템</p>

      {!itemsLoading && items.length > 0 && (
        <div className="tabs">
          {presentCats.map((c) => (
            <button
              key={c}
              className={`tab${c === filter ? " active" : ""}`}
              onClick={() => setFilter(c)}
            >
              {c}
            </button>
          ))}
        </div>
      )}

      {itemsLoading ? (
        <div className="empty">불러오는 중…</div>
      ) : filtered.length > 0 ? (
        <div className="grid">
          {filtered.map((item) => (
            <div className="card" key={item.id}>
              <img src={item.imageBase64} alt={item.name} />
              <button className="del" onClick={() => handleDelete(item.id)}>
                ✕
              </button>
            </div>
          ))}
        </div>
      ) : (
        <div className="empty">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#8A8471" strokeWidth="1.5">
            <rect x="3" y="7" width="18" height="14" rx="1.5" />
            <path d="M8 7V5a4 4 0 0 1 8 0v2" />
          </svg>
          <div>아직 옷장에 저장된 아이템이 없어요</div>
        </div>
      )}
    </AppShell>
  );
}
