"use client";

import { useEffect, useRef, useState } from "react";

export default function Toast() {
  const [msg, setMsg] = useState("");
  const [show, setShow] = useState(false);
  const timerRef = useRef(null);

  useEffect(() => {
    function onToast(e) {
      setMsg(e.detail || "");
      setShow(true);
      clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => setShow(false), 1800);
    }
    window.addEventListener("hc-toast", onToast);
    return () => {
      window.removeEventListener("hc-toast", onToast);
      clearTimeout(timerRef.current);
    };
  }, []);

  return <div className={`toast${show ? " show" : ""}`}>{msg}</div>;
}
