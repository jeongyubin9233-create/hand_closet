"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import Toast from "./Toast";

const TABS = [
  {
    href: "/",
    label: "홈",
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M3 11l9-8 9 8" />
        <path d="M5 10v10h14V10" />
      </svg>
    ),
  },
  {
    href: "/closet",
    label: "내 옷장",
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <rect x="3" y="7" width="18" height="14" rx="1.5" />
        <path d="M8 7V5a4 4 0 0 1 8 0v2" />
      </svg>
    ),
  },
  {
    href: "/outfit",
    label: "코디하기",
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M6 3l6 4 6-4" />
        <path d="M6 3l-3 4 3 3v11h12V10l3-3-3-4" />
      </svg>
    ),
  },
  {
    href: "/lookbook",
    label: "저장한 코디",
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
        <path d="M19 21l-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
      </svg>
    ),
  },
];

export default function AppShell({ children, title, onBack, user, onLogout }) {
  const pathname = usePathname();
  const router = useRouter();

  return (
    <div className="app-frame">
      <header className="app-header">
        {title ? (
          <div className="back-row">
            <button className="back-btn" onClick={onBack || (() => router.back())}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M15 18l-6-6 6-6" />
              </svg>
            </button>
            <div className="header-title">{title}</div>
          </div>
        ) : (
          <Link href="/" className="logo">
            HAND CLOSET
          </Link>
        )}
        {!title && user ? (
          <button className="header-right" onClick={onLogout}>
            로그아웃
          </button>
        ) : (
          <span />
        )}
      </header>

      <main className="app-main">{children}</main>

      {!title && (
        <nav className="tabbar">
          {TABS.map((t) => (
            <Link key={t.href} href={t.href} className={pathname === t.href ? "active" : ""}>
              {t.icon}
              {t.label}
            </Link>
          ))}
        </nav>
      )}

      <Toast />
    </div>
  );
}
