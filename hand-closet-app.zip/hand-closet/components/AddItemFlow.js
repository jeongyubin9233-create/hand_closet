"use client";

import { useEffect, useState } from "react";
import { showToast } from "@/lib/toast";

const CATEGORIES = ["상의", "하의", "아우터", "원피스", "신발", "가방", "액세서리"];

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function AddItemFlow({ source, onClose, onAdded }) {
  // source: { type: 'link', url } | { type: 'upload', file }
  const [step, setStep] = useState("processing"); // processing | form | error
  const [error, setError] = useState("");
  const [statusText, setStatusText] = useState("상품 이미지를 가져오고 있어요…");
  const [processedImage, setProcessedImage] = useState(null);
  const [name, setName] = useState("");
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    run();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function run() {
    try {
      let imageUrl = null;
      let imageBase64 = null;
      let suggestedName = "";

      if (source.type === "link") {
        setStatusText("링크에서 상품 이미지를 찾고 있어요…");
        const res = await fetch("/api/extract-image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: source.url }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "이미지를 가져오지 못했어요.");
        imageUrl = data.imageUrl;
        suggestedName = data.title || "";
      } else {
        suggestedName = source.file.name.replace(/\.[^.]+$/, "");
        imageBase64 = await fileToBase64(source.file);
      }

      setStatusText("배경을 제거하고 있어요…");
      const bgRes = await fetch("/api/remove-bg", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(imageUrl ? { imageUrl } : { imageBase64 }),
      });
      const bgData = await bgRes.json();
      if (!bgRes.ok) throw new Error(bgData.error || "배경 제거에 실패했어요.");

      setProcessedImage(bgData.imageBase64);
      setName(suggestedName.slice(0, 60));
      setStep("form");
    } catch (err) {
      setError(err.message || "처리 중 오류가 발생했어요.");
      setStep("error");
    }
  }

  async function handleConfirm() {
    if (!processedImage) return;
    setSaving(true);
    try {
      const res = await fetch("/api/items", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim() || "이름 없는 아이템",
          category,
          imageBase64: processedImage,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "저장에 실패했어요.");
      showToast("옷장에 추가했어요");
      onAdded && onAdded(data);
      onClose();
    } catch (err) {
      setError(err.message || "저장 중 오류가 발생했어요.");
      setStep("error");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ borderRadius: 18 }}>
        <h3>상품 추가</h3>

        {step === "processing" && (
          <div className="preview-box">
            <div className="processing">
              <div className="spinner" />
              <div>{statusText}</div>
            </div>
          </div>
        )}

        {step === "error" && (
          <>
            <div className="error-box">{error}</div>
            <div className="modal-actions">
              <button className="btn outline" onClick={onClose}>
                닫기
              </button>
              <button className="btn" onClick={() => { setStep("processing"); setError(""); run(); }}>
                다시 시도
              </button>
            </div>
          </>
        )}

        {step === "form" && (
          <>
            <div className="preview-box" style={{ height: 240 }}>
              <img src={processedImage} alt="처리된 이미지" />
            </div>
            <div className="field">
              <label>아이템 이름</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="예: 오버사이즈 코튼 셔츠"
              />
            </div>
            <div className="field">
              <label>카테고리</label>
              <div className="cat-choice">
                {CATEGORIES.map((c) => (
                  <button
                    key={c}
                    type="button"
                    className={c === category ? "active" : ""}
                    onClick={() => setCategory(c)}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
            <div className="modal-actions">
              <button className="btn outline" onClick={onClose} disabled={saving}>
                취소
              </button>
              <button className="btn" onClick={handleConfirm} disabled={saving}>
                {saving ? "저장 중…" : "내 옷장에 추가하기"}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
