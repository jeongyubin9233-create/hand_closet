# HAND CLOSET

링크나 이미지를 올리면 AI가 상품 사진의 배경을 제거해서(누끼) 내 옷장에 저장하고,
코디를 만들어 룩북에 모아볼 수 있는 웹 앱입니다.

## 기능

- 이메일/비밀번호 회원가입·로그인
- 상품 링크 붙여넣기 → `og:image` 자동 추출
- 이미지 업로드 또는 추출된 이미지를 remove.bg API로 배경 제거
- 내 옷장 (카테고리별 아이템 관리)
- 코디하기 (아이템을 보드에 드래그로 배치)
- 저장한 코디 (룩북)

## 시작하기

### 1. 의존성 설치

```bash
npm install
```

### 2. 환경변수 설정

```bash
cp .env.example .env
```

`.env` 파일을 열어 아래 값을 채워주세요.

| 변수 | 설명 |
|---|---|
| `DATABASE_URL` | 기본값(`file:./dev.db`)은 로컬 SQLite. 실제 배포 시엔 Postgres 등으로 교체 필요 |
| `JWT_SECRET` | 로그인 세션 서명용 임의의 긴 문자열 |
| `REMOVE_BG_API_KEY` | [remove.bg](https://www.remove.bg/api)에서 무료 발급받는 배경 제거 API 키 (무료 플랜은 월 50장까지) |

### 3. 데이터베이스 생성

```bash
npx prisma db push
```

### 4. 개발 서버 실행

```bash
npm run dev
```

`http://localhost:3000` 에서 확인할 수 있어요.

## 실제 배포하기 (예: Vercel)

1. GitHub에 이 프로젝트를 올립니다.
2. [Vercel](https://vercel.com)에서 리포지토리를 Import 합니다.
3. **중요:** SQLite 파일은 서버리스 환경(Vercel)에서 유지되지 않아요. 배포 전에:
   - [Neon](https://neon.tech), [Supabase](https://supabase.com) 등에서 무료 Postgres DB를 만들고
   - `prisma/schema.prisma`의 `datasource db` 부분에서 `provider = "sqlite"`를 `provider = "postgresql"`로 변경
   - Vercel 환경변수에 `DATABASE_URL`(Postgres 연결 문자열), `JWT_SECRET`, `REMOVE_BG_API_KEY`를 등록
4. 배포 후 `npx prisma db push`를 한 번 실행해 테이블을 생성해주세요 (로컬에서 프로덕션 `DATABASE_URL`을 가리키게 하고 실행하면 됩니다).

## 알아두면 좋은 점 (한계)

- **링크 자동 추출**은 페이지의 `og:image` 메타태그를 읽는 방식이라, 이 태그가 없거나 JS로 이미지를 그리는 사이트(SPA)에서는 실패할 수 있어요. 이 경우 이미지를 직접 업로드하도록 안내됩니다.
- 일부 쇼핑몰은 크롤링(요청)을 차단할 수 있어요.
- **배경 제거**는 remove.bg API를 사용해요. 무료 플랜은 월 50장 제한이 있고, 이후에는 유료 크레딧이 필요해요. `app/api/remove-bg/route.js`에서 다른 배경 제거 서비스(Clipdrop 등)로 쉽게 교체할 수 있어요.
- 이미지는 현재 base64로 데이터베이스에 직접 저장돼요. 아이템 수가 아주 많아지면 이미지 스토리지(S3, Vercel Blob 등)로 옮기는 걸 추천해요.
- 코디 보드의 아이템 크기 조절/회전은 아직 없어요 (드래그 이동만 가능).

## 프로젝트 구조

```
app/
  page.js              홈 (랜딩 / 아이템 추가)
  login/, signup/       로그인·회원가입
  closet/               내 옷장
  outfit/                코디하기
  lookbook/              저장한 코디
  api/
    auth/                회원가입/로그인/로그아웃/내 정보
    extract-image/        링크 → og:image 추출
    remove-bg/             remove.bg 배경 제거
    items/                 옷장 아이템 CRUD
    looks/                 저장한 코디 CRUD
components/              AppShell, AddItemFlow, Toast
lib/                     prisma, auth(JWT), useAuth, toast
prisma/schema.prisma     User / ClosetItem / Look 모델
```
