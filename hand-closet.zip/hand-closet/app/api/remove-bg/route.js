import { NextResponse } from "next/server";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "handclosetsecretkey123456789";

export async function POST(request) {
  try {
    const { email, password } = await request.json();

    // 입력값 검증
    if (!email || !password) {
      return NextResponse.json(
        { error: "이메일과 비밀번호를 입력해주세요." },
        { status: 400 }
      );
    }

    // 테스트용 유저 객체 생성 (SQLite DB 의존성 제거)
    const user = {
      id: "user-1",
      email: email,
      name: email.split("@")[0],
    };

    // 토큰 생성
    const token = jwt.sign(user, JWT_SECRET, { expiresIn: "7d" });

    const response = NextResponse.json({
      message: "로그인 성공",
      user,
    });

    // 쿠키 설정
    response.cookies.set("token", token, {
      httpOnly: true,
      secure: true,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7, // 7일
      path: "/",
    });

    return response;
  } catch (error) {
    return NextResponse.json(
      { error: "로그인 처리 중 오류가 발생했습니다." },
      { status: 500 }
    );
  }
}